def soma(n1, n2, n3):
    n = n1+ n2+ n3
    return f'A soma é {n}'

n1 = int(input('1º número: '))
n2 = int(input('2º número: '))
n3 = int(input('3º número: '))
print(soma(n1, n2, n3))