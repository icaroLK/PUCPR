def  cadastro(arq, nome, idad):
    a = open(arq.txt)