num = [3, 7, 2, 9, 5, 6]
print(num)
print(f'{sum(num) / len(num):.2f}')