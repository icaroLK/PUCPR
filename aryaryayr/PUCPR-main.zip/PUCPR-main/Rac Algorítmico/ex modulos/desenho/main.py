import desenhar

desenhar.draw(':p')