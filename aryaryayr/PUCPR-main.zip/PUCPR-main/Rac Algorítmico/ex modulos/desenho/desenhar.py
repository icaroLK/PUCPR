'''
modulo desenhar
'''

def draw(desenho):
    print(desenho)

if __name__ == '__main__':
    draw(':)')
    draw('S2')