'''
modulo produtos
'''
import os

def menu():
    os.system('cls')
    print('modulo de produtos')
    input('pressione <enter> para voltar ')

if __name__ == '__main__':
    menu()