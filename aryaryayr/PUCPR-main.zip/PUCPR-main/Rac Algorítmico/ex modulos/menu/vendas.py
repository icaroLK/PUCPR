'''
modulo vendas
'''
import os

def menu():
    os.system('cls')
    print('modulo de vendas')
    input('pressione <enter> para voltar ')

if __name__ == '__main__':
    menu()