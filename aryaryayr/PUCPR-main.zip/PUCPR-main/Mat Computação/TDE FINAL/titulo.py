def title(x):
    print('-' * 30)
    print(f'{x:^30}')
    print('-' * 30)


if __name__ in '__main__':
    title('x')